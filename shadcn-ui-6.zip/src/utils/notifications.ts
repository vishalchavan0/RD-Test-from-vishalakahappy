import { RiskAcceptanceItem } from "@/types";

/**
 * Check if a risk is expiring within the given days
 * @param risk The risk item to check
 * @param daysThreshold Number of days threshold for expiring
 * @returns Boolean indicating if risk is expiring
 */
export function isRiskExpiringSoon(risk: RiskAcceptanceItem, daysThreshold: number = 90): boolean {
  // Skip closed risks
  if (risk.status === "Closed") return false;
  
  // Parse the expiry date string to a Date object
  const expiryDate = new Date(risk.reviewExpiryDate);
  const today = new Date();
  
  // Calculate days until expiry
  const timeDiff = expiryDate.getTime() - today.getTime();
  const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
  
  // Check if the risk expires within the threshold
  return daysDiff >= 0 && daysDiff <= daysThreshold;
}

/**
 * Get a list of all risks expiring within the given days
 * @param daysThreshold Number of days threshold for expiring
 * @returns Array of expiring risk items
 */
export function getExpiringRisks(daysThreshold: number = 90): RiskAcceptanceItem[] {
  try {
    const storedData = localStorage.getItem('riskAcceptanceData');
    if (!storedData) return [];
    
    const risks: RiskAcceptanceItem[] = JSON.parse(storedData);
    return risks.filter(risk => isRiskExpiringSoon(risk, daysThreshold));
  } catch (error) {
    console.error("Error getting expiring risks:", error);
    return [];
  }
}

/**
 * Get email recipients for risk notifications
 * @returns Array of email addresses
 */
export function getNotificationRecipients(): string[] {
  // In a real app, these would come from configuration
  // For this demo, we'll use hardcoded recipients
  return [
    "risk-team@acquia.com",
    "security-team@acquia.com",
    "ciso@acquia.com"
  ];
}

interface NotificationHistoryEntry {
  date: string;
  recipients: string[];
  riskCount: number;
  details: string;
}

/**
 * Add a notification to history
 * @param recipients List of recipients
 * @param riskCount Number of risks notified about
 * @param details Additional details
 */
export function addNotificationToHistory(
  recipients: string[],
  riskCount: number,
  details: string = "Email notification sent for risks expiring in 90 days"
): void {
  try {
    const entry: NotificationHistoryEntry = {
      date: new Date().toISOString(),
      recipients,
      riskCount,
      details
    };
    
    // Get existing history
    const storedHistory = localStorage.getItem('notificationHistory');
    let history: NotificationHistoryEntry[] = [];
    
    if (storedHistory) {
      history = JSON.parse(storedHistory);
    }
    
    // Add new entry and save
    history.unshift(entry);
    localStorage.setItem('notificationHistory', JSON.stringify(history));
  } catch (error) {
    console.error("Error adding notification to history:", error);
  }
}

/**
 * Check for expiring risks and send email notifications
 * @returns Object with success status, count of risks, and message
 */
export function checkAndNotifyExpiringRisks(): { success: boolean; risksExpiring: number; message: string } {
  try {
    const expiringRisks = getExpiringRisks(90);
    
    if (expiringRisks.length === 0) {
      return { 
        success: true, 
        risksExpiring: 0, 
        message: "No risks expiring within the next 90 days" 
      };
    }
    
    const recipients = getNotificationRecipients();
    
    // In a real app, this would call an email API
    // For this demo, we'll simulate the email sending
    console.log(`Sending notifications to ${recipients.join(", ")} for ${expiringRisks.length} risks`);
    
    // Store notification in history
    addNotificationToHistory(
      recipients,
      expiringRisks.length,
      `Email notification sent for ${expiringRisks.length} risks expiring in the next 90 days`
    );
    
    return {
      success: true,
      risksExpiring: expiringRisks.length,
      message: `Notifications sent for ${expiringRisks.length} risks to ${recipients.length} recipients`
    };
  } catch (error) {
    console.error("Error checking and notifying expiring risks:", error);
    return {
      success: false,
      risksExpiring: 0,
      message: `Error: ${error instanceof Error ? error.message : 'Unknown error'}`
    };
  }
}