import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { RiskDataItem, AuditEntry } from "@/types";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

// Form schema validation - only Risk No, Title, and Owner are required
const formSchema = z.object({
  srNo: z.string().optional(), // SR No is now auto-generated and read-only
  riskNo: z.string().min(1, "Risk Number is required"),
  title: z.string().min(1, "Title is required"),
  riskOwner: z.string().min(1, "Risk Owner is required"),
  product: z.string().optional(),
  comments: z.string().optional(),
  orgUnits: z.string().optional(),
  jiraTicket: z.string().optional(),
  status: z.string().min(1, "Status is required"),
  summary: z.string().optional(),
  details: z.string().optional(),
  consequences: z.string().optional(),
  justification: z.string().optional(),
  scenarioType: z.string().optional(),
  // Risk Levels
  inherentOverall: z.string().optional(),
  inherentAvailability: z.string().optional(),
  inherentConfidentiality: z.string().optional(),
  inherentIntegrity: z.string().optional(),
  residualOverall: z.string().optional(),
  residualAvailability: z.string().optional(),
  residualConfidentiality: z.string().optional(),
  residualIntegrity: z.string().optional(),
  auditComment: z.string().optional(),
});

interface User {
  username: string;
  role: string;
  name: string;
}

interface EditRiskFormProps {
  risk: RiskDataItem | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onRiskUpdated: (updatedRisk: RiskDataItem) => void;
}

export function EditRiskForm({ risk, open, onOpenChange, onRiskUpdated }: EditRiskFormProps) {
  const [activeTab, setActiveTab] = useState("details");
  const [user, setUser] = useState<User | null>(null);
  // Store original values for change detection
  const [originalValues, setOriginalValues] = useState<Record<string, any>>({});

  // Get current user from localStorage
  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (userData) {
      setUser(JSON.parse(userData) as User);
    }
  }, []);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      srNo: "",
      riskNo: "",
      title: "",
      riskOwner: "",
      product: "",
      comments: "",
      orgUnits: "",
      jiraTicket: "",
      status: "",
      summary: "",
      details: "",
      consequences: "",
      justification: "",
      scenarioType: "",
      inherentOverall: "",
      inherentAvailability: "",
      inherentConfidentiality: "",
      inherentIntegrity: "",
      residualOverall: "",
      residualAvailability: "",
      residualConfidentiality: "",
      residualIntegrity: "",
      auditComment: "",
    },
  });

  // Update form when risk changes
  useEffect(() => {
    if (risk) {
      // Store original values for change tracking
      const original: Record<string, any> = {
        riskNo: risk.riskNo,
        title: risk.title,
        riskOwner: risk.riskOwner,
        product: risk.product,
        comments: risk.comments,
        orgUnits: risk.orgUnits,
        jiraTicket: risk.jiraTicket,
        status: risk.status,
        summary: risk.summary,
        details: risk.details,
        consequences: risk.consequences,
        justification: risk.justification,
        scenarioType: risk.scenarioType,
        inherentOverall: risk.inherent?.overall || "Low",
        inherentAvailability: risk.inherent?.availability || "Low",
        inherentConfidentiality: risk.inherent?.confidentiality || "Low",
        inherentIntegrity: risk.inherent?.integrity || "Low",
        residualOverall: risk.residual?.overall || "Low",
        residualAvailability: risk.residual?.availability || "Low",
        residualConfidentiality: risk.residual?.confidentiality || "Low",
        residualIntegrity: risk.residual?.integrity || "Low",
      };
      setOriginalValues(original);

      form.reset({
        srNo: risk.srNo,
        riskNo: risk.riskNo,
        title: risk.title,
        riskOwner: risk.riskOwner,
        product: risk.product,
        comments: risk.comments,
        orgUnits: risk.orgUnits,
        jiraTicket: risk.jiraTicket,
        status: risk.status,
        summary: risk.summary,
        details: risk.details,
        consequences: risk.consequences,
        justification: risk.justification,
        scenarioType: risk.scenarioType,
        inherentOverall: risk.inherent?.overall || "Low",
        inherentAvailability: risk.inherent?.availability || "Low",
        inherentConfidentiality: risk.inherent?.confidentiality || "Low",
        inherentIntegrity: risk.inherent?.integrity || "Low",
        residualOverall: risk.residual?.overall || "Low",
        residualAvailability: risk.residual?.availability || "Low",
        residualConfidentiality: risk.residual?.confidentiality || "Low",
        residualIntegrity: risk.residual?.integrity || "Low",
        auditComment: "",
      });
    }
  }, [risk, form]);

  function onSubmit(values: z.infer<typeof formSchema>) {
    if (!risk) return;

    // Track changes for detailed audit trail
    const changes: string[] = [];
    for (const key in values) {
      // Skip audit comment and srNo
      if (key === 'auditComment' || key === 'srNo') continue;
      
      // @ts-ignore - We know these properties exist
      if (values[key] !== originalValues[key]) {
        if (key.includes('inherent') || key.includes('residual')) {
          // Handle risk levels which are nested properties
          changes.push(`Changed ${key.replace('inherent', 'inherent risk').replace('residual', 'residual risk')
            .replace('Overall', ' overall').replace('Availability', ' availability')
            .replace('Confidentiality', ' confidentiality').replace('Integrity', ' integrity')} 
            from "${originalValues[key]}" to "${values[key]}"`);
        } else {
          // Handle regular properties
          changes.push(`Changed ${key} from "${originalValues[key] || ''}" to "${values[key] || ''}"`);
        }
      }
    }

    // Create new audit trail entry
    const newAuditTrail: AuditEntry[] = [...(risk.auditTrail || [])];
    
    // Add user comment if provided
    const auditDetails = values.auditComment?.trim() 
      ? `${values.auditComment}\n\nAutomatic changes log:\n${changes.join('\n')}`
      : `Changes made:\n${changes.join('\n')}`;
    
    // Only add entry if there are changes or a comment
    if (changes.length > 0 || values.auditComment?.trim()) {
      newAuditTrail.push({
        date: new Date().toISOString(),
        user: user?.name || "Current User",
        action: "Updated Risk",
        details: auditDetails,
      });
    }

    // Update the risk with new values
    const updatedRisk: RiskDataItem = {
      ...risk,
      srNo: risk.srNo, // Keep the existing SR No
      riskNo: values.riskNo,
      title: values.title,
      riskOwner: values.riskOwner,
      product: values.product || "",
      comments: values.comments || "",
      orgUnits: values.orgUnits || "",
      jiraTicket: values.jiraTicket || "",
      status: values.status,
      summary: values.summary || "",
      details: values.details || "",
      consequences: values.consequences || "",
      justification: values.justification || "",
      scenarioType: values.scenarioType || "",
      inherent: {
        overall: values.inherentOverall as "High" | "Moderate" | "Low" || "Low",
        availability: values.inherentAvailability as "High" | "Moderate" | "Low" || "Low",
        confidentiality: values.inherentConfidentiality as "High" | "Moderate" | "Low" || "Low",
        integrity: values.inherentIntegrity as "High" | "Moderate" | "Low" || "Low",
      },
      residual: {
        overall: values.residualOverall as "High" | "Moderate" | "Low" || "Low",
        availability: values.residualAvailability as "High" | "Moderate" | "Low" || "Low",
        confidentiality: values.residualConfidentiality as "High" | "Moderate" | "Low" || "Low",
        integrity: values.residualIntegrity as "High" | "Moderate" | "Low" || "Low",
      },
      updatedAt: new Date().toISOString(),
      auditTrail: newAuditTrail,
    };

    // Pass the updated risk to parent component
    onRiskUpdated(updatedRisk);
    form.reset({
      ...values,
      auditComment: "",
    });
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Risk Details</DialogTitle>
          <DialogDescription>
            Update the details for this risk item. Fields marked with * are required.
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-4 mb-4">
            <TabsTrigger value="details">Basic Details</TabsTrigger>
            <TabsTrigger value="description">Description</TabsTrigger>
            <TabsTrigger value="risk-levels">Risk Levels</TabsTrigger>
            <TabsTrigger value="audit-trail">Audit Trail</TabsTrigger>
          </TabsList>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <TabsContent value="details" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="srNo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>SR No (Auto-generated)</FormLabel>
                        <FormControl>
                          <Input {...field} disabled />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="riskNo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Risk No *</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Risk Title *</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="riskOwner"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Risk Owner *</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="product"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Product</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="orgUnits"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Org. Units</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="jiraTicket"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>JIRA Ticket</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Open">Open</SelectItem>
                          <SelectItem value="In Progress - Open">In Progress - Open</SelectItem>
                          <SelectItem value="Closed">Closed</SelectItem>
                          <SelectItem value="Remediated">Remediated</SelectItem>
                          <SelectItem value="Mitigated">Mitigated</SelectItem>
                          <SelectItem value="Risk Accepted">Risk Accepted</SelectItem>
                          <SelectItem value="Risk Expired">Risk Expired</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="scenarioType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Scenario Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select scenario type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Acquia Risk Register">Acquia Risk Register</SelectItem>
                          <SelectItem value="Widen Risk Register">Widen Risk Register</SelectItem>
                          <SelectItem value="Acquia Optimize-Monsido">Acquia Optimize-Monsido</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="comments"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Comments</FormLabel>
                      <FormControl>
                        <Textarea {...field} rows={3} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </TabsContent>

              <TabsContent value="description" className="space-y-4">
                <FormField
                  control={form.control}
                  name="summary"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Summary</FormLabel>
                      <FormControl>
                        <Textarea {...field} rows={3} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="details"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Details</FormLabel>
                      <FormControl>
                        <Textarea {...field} rows={4} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="consequences"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Consequences</FormLabel>
                      <FormControl>
                        <Textarea {...field} rows={3} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="justification"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Justification</FormLabel>
                      <FormControl>
                        <Textarea {...field} rows={3} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </TabsContent>

              <TabsContent value="risk-levels" className="space-y-4">
                <div className="grid grid-cols-2 gap-6">
                  {/* INHERENT Risk Levels */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">INHERENT Risk Levels</CardTitle>
                      <CardDescription>Risk levels before controls are applied</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={form.control}
                        name="inherentOverall"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>OVERALL</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select risk level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="High">High</SelectItem>
                                <SelectItem value="Moderate">Moderate</SelectItem>
                                <SelectItem value="Low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="inherentAvailability"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>AVAILABILITY</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select risk level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="High">High</SelectItem>
                                <SelectItem value="Moderate">Moderate</SelectItem>
                                <SelectItem value="Low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="inherentConfidentiality"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>CONFIDENTIALITY</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select risk level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="High">High</SelectItem>
                                <SelectItem value="Moderate">Moderate</SelectItem>
                                <SelectItem value="Low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="inherentIntegrity"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>INTEGRITY</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select risk level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="High">High</SelectItem>
                                <SelectItem value="Moderate">Moderate</SelectItem>
                                <SelectItem value="Low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                  </Card>

                  {/* RESIDUAL Risk Levels */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">RESIDUAL Risk Levels</CardTitle>
                      <CardDescription>Risk levels after controls are applied</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={form.control}
                        name="residualOverall"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>OVERALL</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select risk level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="High">High</SelectItem>
                                <SelectItem value="Moderate">Moderate</SelectItem>
                                <SelectItem value="Low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="residualAvailability"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>AVAILABILITY</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select risk level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="High">High</SelectItem>
                                <SelectItem value="Moderate">Moderate</SelectItem>
                                <SelectItem value="Low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="residualConfidentiality"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>CONFIDENTIALITY</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select risk level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="High">High</SelectItem>
                                <SelectItem value="Moderate">Moderate</SelectItem>
                                <SelectItem value="Low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="residualIntegrity"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>INTEGRITY</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select risk level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="High">High</SelectItem>
                                <SelectItem value="Moderate">Moderate</SelectItem>
                                <SelectItem value="Low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="audit-trail" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Audit Trail</CardTitle>
                    <CardDescription>History of changes made to this risk</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {risk?.auditTrail && risk.auditTrail.length > 0 ? (
                      <ScrollArea className="h-[300px] pr-4">
                        <div className="space-y-4">
                          {risk.auditTrail.map((entry, index) => (
                            <div key={index} className="border rounded-md p-3 bg-muted/20">
                              <div className="flex justify-between">
                                <span className="text-sm font-medium">
                                  {entry.user} • {entry.action}
                                </span>
                                <span className="text-xs text-muted-foreground">
                                  {new Date(entry.date).toLocaleString()}
                                </span>
                              </div>
                              <p className="text-sm mt-1 whitespace-pre-line">{entry.details}</p>
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    ) : (
                      <p className="text-muted-foreground text-sm">No audit history available for this risk.</p>
                    )}
                  </CardContent>
                </Card>

                <FormField
                  control={form.control}
                  name="auditComment"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Add Comment for this Update</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe what you're changing and why (optional). Changes will be automatically tracked." 
                          {...field} 
                          rows={3}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </TabsContent>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                  Cancel
                </Button>
                <Button type="submit">Save Changes</Button>
              </DialogFooter>
            </form>
          </Form>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}