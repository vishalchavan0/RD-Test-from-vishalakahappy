import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { FileText } from "lucide-react";
import { ClosedRiskItem } from "@/types";

// Form schema for validation
const formSchema = z.object({
  timestamp: z.string().optional(),
  emailAddress: z.string().email({ message: "Please enter a valid email address" }),
  riskNumber: z.string().min(1, { message: "Risk number is required" }),
  riskFrNumber: z.string().min(1, { message: "Risk FR number is required" }),
  riskTitle: z.string().min(1, { message: "Risk title is required" }),
  riskClosureDate: z.string().min(1, { message: "Closure date is required" }),
  riskOwner: z.string().min(1, { message: "Risk owner is required" }),
  riskClosureEvidenceComments: z.string().min(1, { message: "Evidence comments are required" }),
  riskEvidence: z.string().min(1, { message: "Evidence document is required" }),
  reviewedByCiso: z.boolean().default(false),
  approvalFlag: z.boolean().default(false),
  status: z.string().default("Pending"),
  approvalDate: z.string().optional(),
  rafFiled: z.boolean().default(false),
});

interface NewClosureFormProps {
  onClosureCreated: (newClosure: ClosedRiskItem) => void;
}

export function NewClosureForm({ onClosureCreated }: NewClosureFormProps) {
  const [open, setOpen] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      timestamp: new Date().toISOString(),
      emailAddress: "",
      riskNumber: "",
      riskFrNumber: "",
      riskTitle: "",
      riskClosureDate: new Date().toISOString().split('T')[0],
      riskOwner: "",
      riskClosureEvidenceComments: "",
      riskEvidence: "",
      reviewedByCiso: false,
      approvalFlag: false,
      status: "Pending",
      approvalDate: "",
      rafFiled: false,
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    // Create a new closed risk item with form values
    const newClosureItem: ClosedRiskItem = {
      id: `cl-${Date.now()}`, // Generate unique ID
      timestamp: values.timestamp || new Date().toISOString(),
      emailAddress: values.emailAddress,
      riskNumber: values.riskNumber,
      riskFrNumber: values.riskFrNumber,
      riskTitle: values.riskTitle,
      riskClosureDate: values.riskClosureDate,
      riskOwner: values.riskOwner,
      riskClosureEvidenceComments: values.riskClosureEvidenceComments,
      riskEvidence: values.riskEvidence,
      reviewedByCiso: values.reviewedByCiso,
      approvalFlag: values.approvalFlag,
      status: values.approvalFlag ? "Closed" : "Pending",
      approvalDate: values.approvalFlag ? (values.approvalDate || new Date().toISOString().split('T')[0]) : "",
      rafFiled: values.rafFiled,
    };

    // Pass the new closed risk to parent component
    onClosureCreated(newClosureItem);
    setOpen(false);
    form.reset();
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-2">
          <FileText className="h-4 w-4" />
          <span>New Closure Form</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add New Risk Closure</DialogTitle>
          <DialogDescription>
            Enter the details for the new closed risk. All fields marked with * are required.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="emailAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Address *</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="john.doe@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="riskOwner"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk Owner *</FormLabel>
                    <FormControl>
                      <Input placeholder="John Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="riskNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk Number *</FormLabel>
                    <FormControl>
                      <Input placeholder="RSK-001" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="riskFrNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk FR Number *</FormLabel>
                    <FormControl>
                      <Input placeholder="FR-001" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="riskTitle"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Risk Title *</FormLabel>
                  <FormControl>
                    <Input placeholder="Title of the risk" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="riskClosureDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk Closure Date *</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="approvalDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Approval Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormDescription>
                      Only required if already approved
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="riskEvidence"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Risk Evidence Document *</FormLabel>
                  <FormControl>
                    <Input placeholder="evidence.pdf" {...field} />
                  </FormControl>
                  <FormDescription>
                    Enter the document name/path that contains the closure evidence
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="riskClosureEvidenceComments"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Risk Closure Evidence Comments *</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Comments about the closure evidence..." rows={3} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="reviewedByCiso"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Reviewed by CISO</FormLabel>
                    </div>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="approvalFlag"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Approved</FormLabel>
                    </div>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="rafFiled"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>RAF Filed</FormLabel>
                    </div>
                  </FormItem>
                )}
              />
            </div>

            <DialogFooter>
              <Button type="submit">Add Closure</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}