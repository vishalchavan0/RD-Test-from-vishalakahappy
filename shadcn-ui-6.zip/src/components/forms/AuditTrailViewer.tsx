import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { formatDistanceToNow } from 'date-fns';

type AuditEntry = {
  date: string;
  user: string;
  action: string;
  details: string;
};

interface AuditTrailViewerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  type: string;
  item: any; // Risk item with audit trail
  title: string;
}

export function AuditTrailViewer({
  open,
  onOpenChange,
  type,
  item,
  title,
}: AuditTrailViewerProps) {
  const [auditTrail, setAuditTrail] = useState<AuditEntry[]>([]);
  
  useEffect(() => {
    if (item && item.auditTrail) {
      // Sort audit trail by date (newest first)
      const sortedTrail = [...item.auditTrail].sort((a, b) => 
        new Date(b.date).getTime() - new Date(a.date).getTime()
      );
      setAuditTrail(sortedTrail);
    } else {
      setAuditTrail([]);
    }
  }, [item]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[900px] max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-xl">{title}</DialogTitle>
          <DialogDescription>
            Complete history of changes to this {type === 'risk' ? 'risk item' : type === 'risk-acceptance' ? 'risk acceptance' : 'closed risk'}.
          </DialogDescription>
        </DialogHeader>
        
        {auditTrail.length > 0 ? (
          <ScrollArea className="flex-1 border rounded-md">
            <Table>
              <TableHeader className="bg-muted/50 sticky top-0">
                <TableRow>
                  <TableHead className="w-[180px]">Date & Time</TableHead>
                  <TableHead className="w-[150px]">User</TableHead>
                  <TableHead className="w-[150px]">Action</TableHead>
                  <TableHead>Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {auditTrail.map((entry, i) => (
                  <TableRow key={i} className={i % 2 === 0 ? "bg-muted/20" : ""}>
                    <TableCell className="align-top">
                      <div className="font-medium">{new Date(entry.date).toLocaleString()}</div>
                      <div className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(entry.date), { addSuffix: true })}
                      </div>
                    </TableCell>
                    <TableCell className="align-top font-medium">{entry.user || "System"}</TableCell>
                    <TableCell className="align-top">
                      <span className={
                        entry.action.toLowerCase().includes("delete") 
                          ? "text-red-600"
                          : entry.action.toLowerCase().includes("create") 
                            ? "text-green-600" 
                            : entry.action.toLowerCase().includes("update") 
                              ? "text-blue-600"
                              : ""
                      }>
                        {entry.action}
                      </span>
                    </TableCell>
                    <TableCell className="align-top whitespace-pre-wrap">
                      {entry.details}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        ) : (
          <div className="py-8 text-center text-muted-foreground">
            No audit trail available for this item
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}