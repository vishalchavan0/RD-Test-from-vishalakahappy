import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus } from "lucide-react";
import { RiskAcceptanceItem } from "@/types";

// Form schema for validation
const formSchema = z.object({
  srNo: z.string().min(1, { message: "Serial number is required" }),
  riskNo: z.string().min(1, { message: "Risk number is required" }),
  number: z.string().min(1, { message: "Number is required" }),
  title: z.string().min(1, { message: "Title is required" }),
  raFrNoOrCve: z.string().optional(),
  riskFirstAcceptedDate: z.string(),
  raAcceptanceDate: z.string(),
  raEndDate: z.string(),
  raDocumentationStatus: z.string().min(1, { message: "Documentation status is required" }),
  comments: z.string().optional(),
  formReferenceLink: z.string().optional(),
  department: z.string().min(1, { message: "Department is required" }),
  riskLevel: z.enum(["High", "Moderate", "Low"]),
  orgUnits: z.string().min(1, { message: "Org units is required" }),
  status: z.enum(["In place", "In Progress", "Expired"]),
  summary: z.string().min(1, { message: "Summary is required" }),
  details: z.string().min(1, { message: "Details are required" }),
  riskOwner: z.string().min(1, { message: "Risk owner is required" }),
  issueDescription: z.string().min(1, { message: "Issue description is required" }),
  blockade: z.boolean().default(false),
  addedInFair: z.boolean().default(false),
});

interface NewRiskAcceptanceFormProps {
  onRiskAcceptanceCreated: (newRiskAcceptance: RiskAcceptanceItem) => void;
}

export function NewRiskAcceptanceForm({ onRiskAcceptanceCreated }: NewRiskAcceptanceFormProps) {
  const [open, setOpen] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      srNo: "",
      riskNo: "",
      number: "",
      title: "",
      raFrNoOrCve: "",
      riskFirstAcceptedDate: new Date().toISOString().split('T')[0],
      raAcceptanceDate: new Date().toISOString().split('T')[0],
      raEndDate: new Date(new Date().setFullYear(new Date().getFullYear() + 1)).toISOString().split('T')[0],
      raDocumentationStatus: "Complete",
      comments: "",
      formReferenceLink: "",
      department: "",
      riskLevel: "Moderate",
      orgUnits: "",
      status: "In place",
      summary: "",
      details: "",
      riskOwner: "",
      issueDescription: "",
      blockade: false,
      addedInFair: false,
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    // Create a new risk acceptance item with form values
    const newRiskAcceptance: RiskAcceptanceItem = {
      id: `ra-${Date.now()}`, // Generate unique ID
      srNo: values.srNo,
      riskNo: values.riskNo,
      number: values.number,
      title: values.title,
      raFrNoOrCve: values.raFrNoOrCve || "",
      riskFirstAcceptedDate: values.riskFirstAcceptedDate,
      raAcceptanceDate: values.raAcceptanceDate,
      raEndDate: values.raEndDate,
      raDocumentationStatus: values.raDocumentationStatus,
      comments: values.comments || "",
      formReferenceLink: values.formReferenceLink || "",
      department: values.department,
      riskLevel: values.riskLevel,
      orgUnits: values.orgUnits,
      status: values.status,
      summary: values.summary,
      details: values.details,
      riskOwner: values.riskOwner,
      issueDescription: values.issueDescription,
      blockade: values.blockade,
      addedInFair: values.addedInFair,
    };

    // Pass the new risk acceptance to parent component
    onRiskAcceptanceCreated(newRiskAcceptance);
    setOpen(false);
    form.reset();
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          <span>New Risk Acceptance</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add New Risk Acceptance</DialogTitle>
          <DialogDescription>
            Enter the details for the new risk acceptance. All fields marked with * are required.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="srNo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>SR No *</FormLabel>
                    <FormControl>
                      <Input placeholder="RA-001" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="riskNo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk No *</FormLabel>
                    <FormControl>
                      <Input placeholder="RISK-001" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="number"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Number *</FormLabel>
                    <FormControl>
                      <Input placeholder="RA/2023/001" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title *</FormLabel>
                  <FormControl>
                    <Input placeholder="Risk Acceptance Title" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="raFrNoOrCve"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>RA/FR No or CVE</FormLabel>
                    <FormControl>
                      <Input placeholder="CVE-2023-XXXXX" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="riskOwner"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk Owner *</FormLabel>
                    <FormControl>
                      <Input placeholder="John Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="riskFirstAcceptedDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>First Accepted Date *</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="raAcceptanceDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Acceptance Date *</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="raEndDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>End Date *</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="raDocumentationStatus"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Documentation Status *</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Complete">Complete</SelectItem>
                        <SelectItem value="Incomplete">Incomplete</SelectItem>
                        <SelectItem value="In Progress">In Progress</SelectItem>
                        <SelectItem value="Pending Review">Pending Review</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status *</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="In place">In place</SelectItem>
                        <SelectItem value="In Progress">In Progress</SelectItem>
                        <SelectItem value="Expired">Expired</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="department"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Department *</FormLabel>
                    <FormControl>
                      <Input placeholder="IT Security" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="riskLevel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Risk Level *</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select risk level" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="High">High</SelectItem>
                        <SelectItem value="Moderate">Moderate</SelectItem>
                        <SelectItem value="Low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="orgUnits"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Organizational Units *</FormLabel>
                  <FormControl>
                    <Input placeholder="IT, Finance, HR" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="formReferenceLink"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Form Reference Link</FormLabel>
                  <FormControl>
                    <Input placeholder="https://example.com/forms/risk-12345" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="summary"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Summary *</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Brief summary of the risk acceptance..." rows={2} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="details"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Details *</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Detailed description of the risk..." rows={3} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="issueDescription"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Issue Description *</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Description of the issue..." rows={3} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="comments"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Comments</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Additional comments..." rows={2} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex flex-col md:flex-row gap-4">
              <FormField
                control={form.control}
                name="blockade"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Blockade</FormLabel>
                      <FormDescription>
                        Is this risk acceptance a blockade?
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="addedInFair"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Added in FAIR</FormLabel>
                      <FormDescription>
                        Has this been added to FAIR assessment?
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
            </div>

            <DialogFooter>
              <Button type="submit">Add Risk Acceptance</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}